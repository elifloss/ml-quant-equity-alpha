from __future__ import annotations
from pathlib import Path
import pandas as pd
from config import TICKER, RETURNS, VOL_WINDOW, MA_SHORT, MA_LONG

RAW_DIR = Path("data/raw")
PROC_DIR = Path("data/processed")
PROC_DIR.mkdir(parents=True, exist_ok=True)

def main():
    path = RAW_DIR / f"{TICKER}.csv"
    df = pd.read_csv(path, parse_dates=["Date"], index_col="Date")

    px = df["Adj Close"] if "Adj Close" in df.columns else df["Close"]
    df_feat = pd.DataFrame(index=df.index)
    df_feat["close"] = px

    for k in RETURNS:
        df_feat[f"ret_{k}d"] = px.pct_change(k)

    df_feat[f"vol_{VOL_WINDOW}d"] = df_feat["ret_1d"].rolling(VOL_WINDOW).std()

    ma_s = px.rolling(MA_SHORT).mean()
    ma_l = px.rolling(MA_LONG).mean()
    df_feat["ma_ratio"] = (ma_s / ma_l) - 1.0

    df_feat["target_up"] = (px.pct_change(1).shift(-1) > 0).astype(int)

    df_feat = df_feat.dropna()
    out = PROC_DIR / "features.csv"
    df_feat.to_csv(out)
    print(f"Saved: {out}  (rows={len(df_feat)})")

if __name__ == "__main__":
    main()
