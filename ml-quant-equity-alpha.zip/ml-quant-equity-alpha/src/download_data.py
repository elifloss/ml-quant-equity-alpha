from __future__ import annotations
from pathlib import Path
import yfinance as yf
from config import TICKER, START_DATE, END_DATE

RAW_DIR = Path("data/raw")
RAW_DIR.mkdir(parents=True, exist_ok=True)

def main():
    df = yf.download(TICKER, start=START_DATE, end=END_DATE, auto_adjust=False)
    df.index.name = "Date"
    out = RAW_DIR / f"{TICKER}.csv"
    df.to_csv(out)
    print(f"Saved: {out}  (rows={len(df)})")

if __name__ == "__main__":
    main()
