from __future__ import annotations
from pathlib import Path
import pandas as pd
from joblib import dump
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from config import TRAIN_END, VAL_END, RANDOM_STATE
from utils import time_split

PROC_DIR = Path("data/processed")
REP_DIR = Path("reports")
REP_DIR.mkdir(parents=True, exist_ok=True)

def main():
    df = pd.read_csv(PROC_DIR / "features.csv", parse_dates=["Date"], index_col="Date")

    train, val, _ = time_split(df, TRAIN_END, VAL_END)
    X_train, y_train = train.drop(columns=["target_up"]), train["target_up"]
    X_val, y_val = val.drop(columns=["target_up"]), val["target_up"]

    models = {
        "logreg": LogisticRegression(max_iter=2000, random_state=RANDOM_STATE),
        "rf": RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE, n_jobs=-1, max_depth=6),
    }

    best_name, best_model, best_auc = None, None, -1.0
    for name, model in models.items():
        model.fit(X_train, y_train)
        p = model.predict_proba(X_val)[:, 1]
        auc = roc_auc_score(y_val, p)
        print(f"{name}: val ROC-AUC={auc:.4f}")
        if auc > best_auc:
            best_name, best_model, best_auc = name, model, auc

    dump(best_model, REP_DIR / "model.joblib")
    print(f"Saved best model: {best_name} (val ROC-AUC={best_auc:.4f}) -> reports/model.joblib")

if __name__ == "__main__":
    main()
