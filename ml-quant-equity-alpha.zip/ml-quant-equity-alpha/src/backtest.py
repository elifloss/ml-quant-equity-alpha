from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from joblib import load

from config import TRAIN_END, VAL_END, PROB_THRESHOLD, TCOST_BPS
from utils import time_split, bps_to_decimal

PROC_DIR = Path("data/processed")
FIG_DIR = Path("reports/figures")
FIG_DIR.mkdir(parents=True, exist_ok=True)

def main():
    df = pd.read_csv(PROC_DIR / "features.csv", parse_dates=["Date"], index_col="Date")
    model = load("reports/model.joblib")

    _, _, test = time_split(df, TRAIN_END, VAL_END)

    X_test = test.drop(columns=["target_up"])
    close = test["close"]
    next_ret = close.pct_change(1).shift(-1)

    proba = model.predict_proba(X_test)[:, 1]
    signal = (proba > PROB_THRESHOLD).astype(int)

    turnover = np.abs(np.diff(signal, prepend=signal[0]))
    tcost = turnover * bps_to_decimal(TCOST_BPS)

    strat_ret = signal * next_ret.fillna(0.0) - tcost
    bh_ret = next_ret.fillna(0.0)

    strat_curve = (1 + strat_ret).cumprod()
    bh_curve = (1 + bh_ret).cumprod()

    out = pd.DataFrame({
        "proba": proba,
        "signal": signal,
        "next_ret": next_ret,
        "strat_ret": strat_ret,
        "bh_ret": bh_ret,
        "strat_curve": strat_curve,
        "bh_curve": bh_curve,
    }, index=test.index)

    out.to_csv("reports/backtest.csv")
    print("Saved: reports/backtest.csv")

    plt.figure()
    strat_curve.plot(label="ML Strategy")
    bh_curve.plot(label="Buy & Hold")
    plt.title("Equity Curve")
    plt.legend()
    fig_path = FIG_DIR / "equity_curve.png"
    plt.savefig(fig_path, dpi=200, bbox_inches="tight")
    print(f"Saved: {fig_path}")

if __name__ == "__main__":
    main()
