from __future__ import annotations
import pandas as pd

def time_split(df: pd.DataFrame, train_end: str, val_end: str):
    train = df.loc[:train_end].copy()
    val = df.loc[pd.Timestamp(train_end) + pd.Timedelta(days=1):val_end].copy()
    test = df.loc[pd.Timestamp(val_end) + pd.Timedelta(days=1):].copy()
    return train, val, test

def bps_to_decimal(bps: float) -> float:
    return bps / 10000.0
