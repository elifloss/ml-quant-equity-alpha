# ML-Driven Quant Equity Strategy

This repo is a **portfolio-ready** starter kit for an ML-driven trading strategy:
- Predict next-day returns (classification or regression)
- Convert predictions into long/flat signals
- Backtest with transaction costs and risk controls

> **Important:** This is for educational/portfolio purposes only and is not financial advice.

## Quickstart
```bash
pip install -r requirements.txt
python src/download_data.py
python src/features.py
python src/train.py
python src/backtest.py
```

## Project Structure
- `data/raw/` downloaded OHLCV
- `data/processed/` feature/label table
- `notebooks/` EDA and analysis
- `src/` pipeline code (download → features → train → backtest)
- `reports/figures/` output charts

## Key Ideas to Highlight on Your Resume
- Time-series safe splits (walk-forward)
- Feature engineering + leakage prevention
- Benchmarking vs buy-and-hold
- Risk management + transaction costs
